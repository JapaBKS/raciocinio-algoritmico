tecnicas_personagens = {
    'Goku': ['Kamehameha', 'Spirit Bomb', 'Genki Dama'],
    'Vegeta': ['Final Flash', 'Galick Gun'],
    'Gohan': ['Masenko', 'Father-Son Kamehameha'],
    'Piccolo': ['Special Beam Cannon', 'Light Grenade'],
    'Freeza': ['Death Beam', 'Supernova'],
    'Cell': ['Kamehameha', 'Solar Kamehameha'],
    'Bills': ['Hakai'],
    'Whis': ['Temporal Do-Over', 'Warp'],
}

tecnicas_personagens['Goku'].append('Kaio-Ken')

print(tecnicas_personagens)