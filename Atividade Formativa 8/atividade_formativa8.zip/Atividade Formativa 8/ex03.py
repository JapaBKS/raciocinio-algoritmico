dragonball_transformacoes = {
    'Goku': ['Super Saiyajin', 'Super Saiyajin Deus'],
    'Vegeta': ['Super Saiyajin'],
    'Gohan': ['Super Saiyajin', 'Ultimate Gohan'],
    'Piccolo': ['Namekian Fusion', 'Super Namekian'],
    'Freeza': ['Final Form', 'Golden Freeza'],
    'Cell': ['Imperfect Form', 'Perfect Form'],
    'Bills': ['God of Destruction'],
    'Whis': ['Angel']
}

dragonball_transformacoes['Goku'].remove('Super Saiyajin Deus')

print(dragonball_transformacoes)