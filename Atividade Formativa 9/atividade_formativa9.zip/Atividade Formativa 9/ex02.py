def raiz_quadrada(n):
    '''Calcula a raíz quadrada de um número recebido'''
    print(n**(1/2))

n = int(input('Digite um número para ver a sua raíza quadrada: '))
raiz_quadrada(n)