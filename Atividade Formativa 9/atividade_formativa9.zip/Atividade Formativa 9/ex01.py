def dobro(n):
    '''Calcula o dobro de um número recebido'''
    print(n*2)

n = int(input('Digite um número para ver o seu dobro: '))
dobro(n)