n1 = int(input('Digite um número: '))
n2 = int(input('Digite outro número: '))

soma = 0

for n1 in range (n1, n2-1):
    soma+=n1+1
print(soma)