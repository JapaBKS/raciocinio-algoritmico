n1 = int(input('Digite um número: '))
n2 = int(input('Digite outro número: '))

for n1 in range (n1, n2-1):
    print(n1+1)