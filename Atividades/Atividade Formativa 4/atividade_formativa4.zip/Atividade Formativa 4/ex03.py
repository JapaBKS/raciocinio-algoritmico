i=1

while(i<=10):
    print(i, "² =",i**2)
    i+=1