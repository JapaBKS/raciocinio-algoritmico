n = int(input("Digite um número para ver a sua tabuada: "))

for i in range (11):
    print(n,"x", i, "=",i*n)