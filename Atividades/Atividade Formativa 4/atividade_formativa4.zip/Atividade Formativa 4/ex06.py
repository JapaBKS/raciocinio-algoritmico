for i in range(1, 51, 5):
    print(i)