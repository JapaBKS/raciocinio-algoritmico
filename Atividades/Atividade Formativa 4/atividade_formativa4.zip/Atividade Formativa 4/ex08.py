i=0
soma=0

while(i<5):
    n = int(input("Digite um número: "))
    soma+=n
    i+=1
print("A media dos 5 números digitados é igual a:", soma/5)