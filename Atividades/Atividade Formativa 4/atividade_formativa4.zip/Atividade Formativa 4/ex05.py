n = int(input("Digite um número para calcular seu fatorial: "))
fat=1

while(n>0):
    fat*=n
    n-=1
print(fat)