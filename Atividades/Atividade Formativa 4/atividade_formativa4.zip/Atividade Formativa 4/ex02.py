soma=0

for i in range(101):
    soma+=i
    i+=1
print(soma)