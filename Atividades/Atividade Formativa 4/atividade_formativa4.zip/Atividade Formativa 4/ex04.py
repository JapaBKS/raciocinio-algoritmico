for i in range (100, 0, -1):
    print(i)