#Tabuada do 5 usando while

i = 1

while (i<=10):
    print(i, 'x 5 = ', i*5)
    i+=1