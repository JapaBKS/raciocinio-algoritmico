#Tabuada do 5 usando for

for i in range(10):
    print(i+1, 'x 5 = ', (i+1)*5)
    i+=1