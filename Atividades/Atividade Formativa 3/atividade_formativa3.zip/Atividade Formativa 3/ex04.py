#Inicie uma contagem regressiva a partir de um número especificado pelo usuário
#até 0, empregando um loop (while).

num = int(input('Digite um número para a contagem regressiva: '))

while(num>=0):
    print(num)
    num-=1