#Faça um Programa que peça um número e então mostre a mensagem "O número informado foi [número]."

num = int(input('Digite um número: '))

print('O número digitado foi {}'.format(num))