#Faça um Programa que peça as 4 notas bimestrais e mostre a média.

n1 = float(input('Digite um número: '))
n2 = float(input('Digite outro número: '))
n3 = float(input('Digite outro número: '))
n4 = float(input('Digite outro número: '))

soma = n1+n2+n3+n4
media = soma/4

print('A média entre as notas acima é igual a: {:.2f}'.format(media))