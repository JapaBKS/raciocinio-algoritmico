#Faça um programa que mostre a mensagem "Alô mundo" na tela.

print('Alô mundo')