#Faça um Programa que peça dois números e imprima a soma.

n1 = int(input('Digite um número: '))
n2 = int(input('Digite outro número: '))

soma = n1+n2

print('A soma entre {} e {} é igual a: {}'.format(n1, n2, soma))